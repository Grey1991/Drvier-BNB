create procedure test_insert()
  BEGIN
  DECLARE i INT DEFAULT 50;
  START TRANSACTION;
  WHILE i<60
  DO
  INSERT INTO `comp9900db`.`Property_property` (`id`, `price`, `types_property`, `province`, `city`, `state`, `address`, `postcode`, `capacity`, `num_bathrooms`, `num_bedrooms`, `num_double_bed`, `num_single_bed`, `num_sofa_bed`, `area`, `kitchen`, `in_unit_washer`, `wifi`, `elevator`, `heating`, `ac`, `tv`, `blower`, `bathtub`, `parking`, `gyms`, `swimming_pool`, `party`, `pet`, `smoking`, `couple`, `longitude`, `latitude`, `created_at`, `updated_at`, `status`, `user_ID_id`)
  VALUES (i, 200, 'H', 'a', 'Melbourne', 'NSW', 'd', 1122, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '1970-01-01 00:00:00.000000', '2018-08-27 18:07:37.256000', 0, 1);


  SET i=i+1;
  END WHILE;
  COMMIT;
END;

