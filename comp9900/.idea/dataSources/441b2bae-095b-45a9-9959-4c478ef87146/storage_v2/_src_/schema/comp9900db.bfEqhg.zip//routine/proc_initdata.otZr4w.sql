create procedure proc_initData()
  BEGIN
    DECLARE i INT DEFAULT 61;
    WHILE i<=80 DO
        INSERT INTO Property_property(id,price,types_property,province,city,state,address,postcode,num_bathrooms,num_double_bed,num_single_bed,num_bedrooms,num_sofa_bed,capacity,area,kitchen,in_unit_washer,wifi,elevator,heating,ac,tv,blower,bathtub,parking,gyms,swimming_pool,party,pet,smoking,couple,longitude,latitude,created_at,updated_at,status,user_ID_id)
        VALUES(i,250.0,'A','NSW','Newcastle','NSW',concat('Unit ',i-30,' King St'),2302,i%2+1,i%2+1,i%3+1,num_double_bed+num_single_bed,1%2,num_double_bed*2+num_single_bed+num_sofa_bed,90+(i%4)*5,i%5>0,i%5>0,1,i%4>0,i%7>0,i%3>0,1,i%7>0,i%6>0,i%12>0,i%5>0,i%5>0,i%3>0,i%3>0,i%2>0,1,0.0,0.0,18/09/10,18/09/10,1,4);
        SET i = i+1;
    END WHILE;
END;

