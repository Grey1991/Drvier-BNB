create procedure proc_initimage()
  BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE j INT DEFAULT (i-1)/5+1;
    WHILE i<=400 DO
#         UPDATE Property_images SET pid_id=i WHERE id=i;
        INSERT INTO Property_images(id,image,pid_id)
        VALUES(i,CONCAT('img/room_detail_',i%5+1,'.jpg'),j);
        IF i%5 = 0 THEN
            SET j = j + 1;
        END IF;
        SET i = i+1;
    END WHILE;
END;

